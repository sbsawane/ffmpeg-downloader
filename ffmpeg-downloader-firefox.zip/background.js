// Cross-browser compatibility (Chrome uses 'chrome', Firefox uses 'browser')
const API = typeof browser !== 'undefined' ? browser : chrome;

// Listen for media files
const MEDIA_EXTENSIONS = ['.m3u8', '.mpd', '.mp4', '.flv'];

// Helper function for setting badge (works with both Chrome MV3 and Firefox MV2)
function setBadge(text) {
  try {
    if (typeof browser !== 'undefined') {
      // Firefox MV2
      browser.browserAction.setBadgeText({ text: text });
    } else {
      // Chrome MV3
      chrome.action.setBadgeText({ text: text });
    }
  } catch (e) {
    console.log("Badge not supported:", e.message);
  }
}

// Initialize
try {
  // Clear storage on startup
  API.storage.local.remove('last_stream');
  setBadge("");
} catch (e) {
  console.log("Initialization error:", e.message);
}

// Monitor web requests for media files (Chrome MV3 compatible)
try {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      const url = details.url;
      if (MEDIA_EXTENSIONS.some(ext => url.includes(ext))) {
        // Filter out small segments to avoid spam
        if (!url.includes('.m4s') && !url.includes('.ts')) {
          
          // Save URL and show badge
          API.storage.local.set({ last_stream: url });
          setBadge("!");
        }
      }
    },
    { urls: ["<all_urls>"] }
  );
} catch (e) {
  console.log("webRequest not available:", e.message);
}

// 3. Handle Download Messages and Kill Commands
API.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.command === "download") {
    console.log("Download request:", message);
    API.runtime.sendNativeMessage(
      "com.my_downloader",
      { url: message.url, filename: message.filename },
      (response) => {
        if (API.runtime.lastError) {
          const errorMsg = API.runtime.lastError.message || "Unknown native host error";
          console.error("Native Host Error:", errorMsg);
          sendResponse({ status: "error", error: errorMsg });
        } else if (response && response.status === "success") {
          console.log("Download started successfully:", response);
          sendResponse({ 
            status: "started", 
            pid: response.pid, 
            filename: response.filename, 
            path: response.path 
          });
          
          // Start monitoring progress
          if (response.pid) {
            startProgressMonitoring(response.pid);
          }
        } else if (response && response.status === "error") {
          console.error("FFmpeg error:", response.message);
          sendResponse({ status: "error", error: response.message || "FFmpeg failed to start" });
        } else {
          console.warn("Unexpected response from native host:", response);
          sendResponse({ status: "error", error: "Invalid response from native host" });
        }
      }
    );
    return true; 
  }
  
  if (message.command === "kill") {
    const pid = message.pid;
    if (pid) {
      API.runtime.sendNativeMessage(
        "com.my_downloader",
        { command: "kill", pid: pid },
        (response) => {
          console.log("Kill response:", response);
          sendResponse({ status: "killed" });
        }
      );
      return true;
    }
  }
});

// Monitor progress by polling the native host
function startProgressMonitoring(pid) {
  let progressCheckCount = 0;
  const maxChecks = 3600; // Check for max 30 minutes (0.5s * 3600)
  
  const progressInterval = setInterval(() => {
    progressCheckCount++;
    
    if (progressCheckCount > maxChecks) {
      clearInterval(progressInterval);
      return;
    }
    
    // Check if recording is still active
    API.storage.local.get(['currentPID', 'isRecording'], (result) => {
      if (result.currentPID !== pid || !result.isRecording) {
        clearInterval(progressInterval);
        return;
      }
      
      // Ask native host for progress
      API.runtime.sendNativeMessage(
        "com.my_downloader",
        { command: "get-progress", pid: pid },
        (response) => {
          if (response && response.status === "progress") {
            // Update storage with progress
            API.storage.local.set({
              downloadSize: response.downloaded,
              downloadTotal: response.estimated_total || 0
            });
          }
        }
      );
    });
  }, 500);
}