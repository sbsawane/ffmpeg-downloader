// Cross-browser compatibility
const API = typeof browser !== 'undefined' ? browser : chrome;

let progressInterval = null;

document.addEventListener('DOMContentLoaded', () => {
  const urlInput = document.getElementById('urlInput');
  const filenameInput = document.getElementById('filename');
  const downloadBtn = document.getElementById('downloadBtn');
  const stopBtn = document.getElementById('stopBtn');
  const statusMsg = document.getElementById('statusMsg');
  const progressWheel = document.getElementById('progressWheel');
  const progressInfo = document.getElementById('progressInfo');
  const progressBar = document.getElementById('progressBar');
  const progressFill = document.getElementById('progressFill');
  
  // Load last detected stream and check recording status
  API.storage.local.get(['last_stream', 'isRecording', 'currentPID', 'currentFilename', 'currentPath'], (result) => {
    if (result.last_stream) {
      urlInput.value = result.last_stream;
    } else {
      urlInput.placeholder = "Play a video on any website to detect the stream";
    }
    
    // Restore recording state
    if (result.isRecording && result.currentPID) {
      downloadBtn.style.display = 'none';
      stopBtn.style.display = 'block';
      progressWheel.style.display = 'block';
      progressInfo.style.display = 'block';
      statusMsg.innerHTML = `▶ Download in progress...<br><small>File: ${result.currentFilename}<br>PID: ${result.currentPID}</small>`;
      
      // Start monitoring progress
      startProgressMonitoring();
    } else {
      // Reset UI if recording state is invalid
      downloadBtn.style.display = 'block';
      stopBtn.style.display = 'none';
      progressWheel.style.display = 'none';
      progressInfo.style.display = 'none';
      progressBar.style.display = 'none';
    }
  });

  function startProgressMonitoring() {
    if (progressInterval) clearInterval(progressInterval);
    
    let lastDownloaded = 0;
    let lastTime = Date.now();
    
    progressInterval = setInterval(() => {
      API.storage.local.get(['downloadProgress', 'downloadSize', 'downloadTotal'], (result) => {
        if (result.downloadSize !== undefined && result.downloadTotal !== undefined) {
          const downloaded = result.downloadSize;
          const total = result.downloadTotal;
          const percent = total > 0 ? Math.round((downloaded / total) * 100) : 0;
          
          progressBar.style.display = 'block';
          progressFill.style.width = percent + '%';
          
          const downloadedMB = (downloaded / (1024 * 1024)).toFixed(2);
          const totalMB = (total / (1024 * 1024)).toFixed(2);
          
          // Calculate download speed and estimated time
          const now = Date.now();
          const timeDiff = (now - lastTime) / 1000; // seconds
          const byteDiff = downloaded - lastDownloaded;
          let speedMBps = 0;
          let estimatedSeconds = 0;
          let timeRemaining = "Calculating...";
          
          if (timeDiff > 0 && byteDiff > 0) {
            speedMBps = (byteDiff / (1024 * 1024)) / timeDiff;
            const remainingBytes = total - downloaded;
            estimatedSeconds = remainingBytes / (speedMBps * 1024 * 1024);
            
            if (estimatedSeconds > 60) {
              const mins = Math.floor(estimatedSeconds / 60);
              const secs = Math.floor(estimatedSeconds % 60);
              timeRemaining = `${mins}m ${secs}s remaining`;
            } else if (estimatedSeconds > 0) {
              timeRemaining = `${Math.floor(estimatedSeconds)}s remaining`;
            }
          }
          
          lastDownloaded = downloaded;
          lastTime = now;
          
          progressInfo.innerHTML = `
            <div id="progressPercent">${percent}%</div>
            <div id="progressSizes">${downloadedMB} MB / ${totalMB} MB</div>
            <div id="progressSpeed">${speedMBps.toFixed(2)} MB/s · ${timeRemaining}</div>
          `;
        } else if (result.downloadProgress !== undefined) {
          progressBar.style.display = 'block';
          // Pulsing animation for indeterminate
          const angle = (Date.now() % 2000) / 2000 * 100;
          progressFill.style.width = Math.sin(angle * Math.PI) * 30 + 50 + '%';
        }
      });
    }, 500);
  }

  downloadBtn.addEventListener('click', () => {
    const url = urlInput.value;
    let filename = filenameInput.value;
    
    if(!url) return alert("No stream detected yet!");

    statusMsg.innerHTML = "⏳ Starting download...";
    
    API.runtime.sendMessage({ command: "download", url: url, filename: filename }, (response) => {
      if(response && response.status === "started") {
        const actualFilename = response.filename || filename;
        const pid = response.pid;
        
        // Save recording state
        API.storage.local.set({
          isRecording: true,
          currentPID: pid,
          currentFilename: actualFilename,
          currentPath: response.path || "Unknown",
          downloadProgress: 0,
          downloadSize: 0,
          downloadTotal: 0
        });
        
        statusMsg.innerHTML = 
          `✓ Download Started!<br><small>File: ${actualFilename}<br>PID: ${pid}</small>`;
        downloadBtn.style.display = 'none';
        stopBtn.style.display = 'block';
        progressWheel.style.display = 'block';
        progressInfo.style.display = 'block';
        progressBar.style.display = 'block';
        
        // Start monitoring progress
        startProgressMonitoring();
      } else {
        const errorMsg = response && response.error ? response.error : "Unknown error starting download";
        statusMsg.innerHTML = `❌ <strong>Error:</strong><br><small>${errorMsg}</small>`;
        downloadBtn.style.display = 'block';
        stopBtn.style.display = 'none';
        progressWheel.style.display = 'none';
        progressInfo.style.display = 'none';
        progressBar.style.display = 'none';
        console.error("Download error:", errorMsg);
      }
    });
  });

  stopBtn.addEventListener('click', () => {
    API.storage.local.get(['currentPID'], (result) => {
      const pid = result.currentPID;
      if (pid) {
        // Disable button during kill
        stopBtn.disabled = true;
        stopBtn.innerText = "⏳ Stopping...";
        statusMsg.innerHTML = "⏳ Stopping download...";
        
        // Send kill command to background script
        API.runtime.sendMessage({ command: "kill", pid: pid }, (response) => {
          if (API.runtime.lastError || !response) {
            statusMsg.innerHTML = "⚠️ Stop command sent, but process may still be running. Check logs.";
            console.error("Kill error:", API.runtime.lastError || "No response");
          } else {
            statusMsg.innerHTML = "✓ Download stopped";
          }
          
          // Reset state after a delay
          setTimeout(() => {
            API.storage.local.set({
              isRecording: false,
              currentPID: null,
              currentFilename: null,
              currentPath: null,
              downloadProgress: 0,
              downloadSize: 0,
              downloadTotal: 0
            });
            
            progressWheel.style.display = 'none';
            progressInfo.style.display = 'none';
            progressBar.style.display = 'none';
            progressFill.style.width = '0%';
            downloadBtn.style.display = 'block';
            stopBtn.style.display = 'none';
            stopBtn.disabled = false;
            stopBtn.innerText = "⏹ Stop Download";
            
            if (progressInterval) clearInterval(progressInterval);
            
            setTimeout(() => {
              statusMsg.innerHTML = '';
            }, 3000);
          }, 500);
        });
      }
    });
  });
});